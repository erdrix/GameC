/**
 * The package contains ComponentUI implementation specific for Windows L&F.
 */
package com.jidesoft.plaf.windows;