/*
 * @(#) GripperUI.java
 * Last modified date: 2/1/2005
 *
 * Copyright 2002 - 2005 JIDE Software Inc. All rights reserved.
 */
package com.jidesoft.plaf;

import javax.swing.plaf.ComponentUI;

/**
 * UI class for Gripper.
 */
public abstract class GripperUI extends ComponentUI {
}

