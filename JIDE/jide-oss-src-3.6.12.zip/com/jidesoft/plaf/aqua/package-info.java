/**
 * The package contains ComponentUI implementation for Aqua style.
 */
package com.jidesoft.plaf.aqua;