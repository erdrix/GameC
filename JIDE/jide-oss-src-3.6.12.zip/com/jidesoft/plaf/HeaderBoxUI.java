/*
 * @(#)HeaderBoxUI.java 4/27/2006
 *
 * Copyright 2002 - 2006 JIDE Software Inc. All rights reserved.
 */

package com.jidesoft.plaf;

import javax.swing.plaf.ButtonUI;

/**
 * Pluggable look and feel interface for HeaderBox.
 */
public abstract class HeaderBoxUI extends ButtonUI {
}
